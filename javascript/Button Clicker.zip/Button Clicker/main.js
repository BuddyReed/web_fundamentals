// Remove the Add Definition Button
function remove(element){
    element.remove()
}

// login button change
var navbtm = "Logout"
function buttonClick(element){
    element.innerText = `Logout`
}

// Alert Buttons

function showAlert(){
    alert("Ninja was liked")
}